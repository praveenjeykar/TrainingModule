package PaymentDetails;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.PaymentDetailsPageFactory;
import PageBean.PersonalInformationPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DebitCardDetailsStepDefination {
	
	 private WebDriver driver;
	    private PaymentDetailsPageFactory paymentPageFactory;
	    
	    @Before
	    public void setUp() {
	    	System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\mbeera\\Documents\\chromedriver_win32\\chromedriver.exe" );
			driver= new ChromeDriver();
	    }
	@Given("^user is on 'PaymentDetails' page$")
	public void user_is_on_PaymentDetails_page() throws Throwable {
		driver.get("C:\\Users\\mbeera\\Desktop\\bdd jars\\UserInfoPayment\\PaymentDetails.html");
	    paymentPageFactory= new PaymentDetailsPageFactory(driver);
	}

	@Then("^'Pleas check the Title of the page'$")
	public void pleas_check_the_Title_of_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid Card Holder Name$")
	public void user_enters_invalid_Card_Holder_Name() throws Throwable {
		  paymentPageFactory.setName("");;
	        paymentPageFactory.clickPaymentButton();;
	    throw new PendingException();
	}

	@When("^Click on the Make Payment$")
	public void click_on_the_Make_Payment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill the Card Holder name'$")
	public void displays_Please_fill_the_Card_Holder_name() throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.switchTo().alert().accept();
        driver.close();
        
	}

	@When("^user enters invalid Debit card Number$")
	public void user_enters_invalid_Debit_card_Number() throws Throwable {
		   paymentPageFactory.setName("");
	        paymentPageFactory.setCardNumber("");
	        paymentPageFactory.clickPaymentButton();
	      
	}

	@Then("^displays 'Please fill the Debit card Number'$")
	public void displays_Please_fill_the_Debit_card_Number() throws Throwable {
		 driver.switchTo().alert().accept();
	        driver.close();
	      
	}

	@When("^user enters invalid Card expiration month$")
	public void user_enters_invalid_Card_expiration_month() throws Throwable {
		 paymentPageFactory.setName("");
	        paymentPageFactory.setCardNumber("83472384");
	      
	        paymentPageFactory.setExpirationMonth("");
	        paymentPageFactory.clickPaymentButton();
	     

	}

	@Then("^displays 'Please fill the expiration month'$")
	public void displays_Please_fill_the_expiration_month() throws Throwable {
		 driver.switchTo().alert().accept();
	        driver.close();
	      
	}

	@When("^user enters invalid Card expiration year$")
	public void user_enters_invalid_Card_expiration_year() throws Throwable {
		 paymentPageFactory.setName("");
	        paymentPageFactory.setCardNumber("83472384");
	       
	        paymentPageFactory.setExpirationMonth("12");
	        paymentPageFactory.setExpiartionYear("");
	        paymentPageFactory.clickPaymentButton();
	      
	}

	@Then("^displays 'Please fill the expiration year'$")
	public void displays_Please_fill_the_expiration_year() throws Throwable {
		driver.switchTo().alert().accept();
        driver.close();
        
	}

	@When("^user enters valid PaymentDetails details$")
	public void user_enters_valid_PaymentDetails_details() throws Throwable {
		 paymentPageFactory.setName("");
	        paymentPageFactory.setCardNumber("83472384");
	        paymentPageFactory.setExpirationMonth("12");
	        paymentPageFactory.setExpiartionYear("1998");
	        paymentPageFactory.clickPaymentButton();
	        
	}

	@Then("^displays 'Pan Card Registration Done Successfully!!!'$")
	public void displays_Pan_Card_Registration_Done_Successfully() throws Throwable {
		driver.switchTo().alert().accept();
        driver.close();
      
	}


}
