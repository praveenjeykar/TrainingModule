package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsPageFactory {
WebDriver driver;
    
    @FindBy(id="txtCardholderName")
    @CacheLookup
    WebElement name;
    
    @FindBy(name="debit")
    @CacheLookup
    WebElement cardNumber;
    
    
    @FindBy(how=How.NAME, using="month")
    @CacheLookup
    WebElement expirationMonth;
    
    @FindBy(xpath="//*[@id='txtYear']")
    @CacheLookup
    WebElement expiartionYear;
    
    @FindBy(id="btnPayment")
    @CacheLookup
    WebElement paymentButton;
    
    public String getName() {
        return this.name.getAttribute("value");
    }

    public void setName(String name) {
        this.name.sendKeys(name);
    }

    public String getCardNumber() {
        return cardNumber.getAttribute("value");
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber.sendKeys(cardNumber);
    }

    public String getExpirationMonth() {
        return expirationMonth.getAttribute("value");
    }

    public void setExpirationMonth(String expirationMonth) {
        this.expirationMonth.sendKeys(expirationMonth);
    }

    public String getExpiartionYear() {
        return expiartionYear.getAttribute("value");
    }

    public void setExpiartionYear(String expiartionYear) {
        this.expiartionYear.sendKeys(expiartionYear);
    }
    
    public void clickPaymentButton() {
        paymentButton.click();
    }
    //initiating Elements
        public PaymentDetailsPageFactory(WebDriver driver) {
            this.driver = driver;
            PageFactory.initElements(driver, this);
        }
}
