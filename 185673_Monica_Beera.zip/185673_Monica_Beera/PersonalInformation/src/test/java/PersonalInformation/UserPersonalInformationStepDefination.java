package PersonalInformation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.PersonalInformationPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class UserPersonalInformationStepDefination {
private WebDriver driver;
private PersonalInformationPageFactory PIPageFactory;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\mbeera\\Documents\\chromedriver_win32\\chromedriver.exe" );
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'PersonalInformation' page$")
	public void user_is_on_PersonalInformation_page() throws Throwable {
		driver.get("C:\\Users\\mbeera\\Desktop\\bdd jars\\UserInfoPayment.html");
		PIPageFactory= new PersonalInformationPageFactory(driver);

	}

	@When("^user enters invalid Applicant Name$")
	public void user_enters_invalid_Applicant_Name() throws Throwable {
		PIPageFactory.setApplicantName("");
		PIPageFactory.setConfirmButton();
	    throw new PendingException();
	}

	@When("^Click on the Submit$")
	public void click_on_the_Submit() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill the Applicant Name'$")
	public void displays_Please_fill_the_Applicant_Name() throws Throwable {
		String expectedMessage="Please fill the Applicant Name";
		String actualMessage=PIPageFactory.getApplicantName().getText();
				if(expectedMessage.equals(actualMessage))
		            driver.switchTo().alert().accept();
		        else
		            System.out.println("Correct Name...");
		       
		        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		        driver.close();   
		    }
	

	@When("^user enters invalid First Name$")
	public void user_enters_invalid_First_Name() throws Throwable {
		PIPageFactory.setFirstName("");
		PIPageFactory.setConfirmButton();
		    }

	@Then("^displays 'Please fill the First Name'$")
	public void displays_Please_fill_the_First_Name() throws Throwable {
		
		String expectedMessage="Please fill the First Name";
		String actualMessage=PIPageFactory.getFirstName().getText();
				if(expectedMessage.equals(actualMessage))
		            driver.switchTo().alert().accept();
		        else
		            System.out.println("Correct Name...");
		       
		        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		        driver.close();   
		    }


	@When("^user enters invalid last Name$")
	public void user_enters_invalid_last_Name() throws Throwable {
		PIPageFactory.setFirstName("");
		PIPageFactory.setConfirmButton();
	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage="Please fill the Last Name";
		String actualMessage=PIPageFactory.getFirstName().getText();
				if(expectedMessage.equals(actualMessage))
		            driver.switchTo().alert().accept();
		        else
		            System.out.println("Correct Name...");
		       
		        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		        driver.close();   
	}

	@When("^user enters invalid Father Name$")
	public void user_enters_invalid_Father_Name() throws Throwable {
		PIPageFactory.setFatherName("");
		PIPageFactory.setConfirmButton();
	}

	@Then("^displays 'Please fill the Father Name'$")
	public void displays_Please_fill_the_Father_Name() throws Throwable {
		
		String expectedMessage="Please fill the Father Name";
		String actualMessage=PIPageFactory.getFatherName().getText();
				if(expectedMessage.equals(actualMessage))
		            driver.switchTo().alert().accept();
		        else
		            System.out.println("Correct Name...");
		       
		        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		        driver.close();
	}

	@When("^user enters invalid Date of Birth$")
	public void user_enters_invalid_Date_of_Birth() throws Throwable {
		PIPageFactory.setDateofBirth("");
		PIPageFactory.setConfirmButton();
	}

	@Then("^displays 'Please fill the Date of Birth'$")
	public void displays_Please_fill_the_Date_of_Birth() throws Throwable {
	  
		String expectedMessage="Please fill the Date of Birth";
		String actualMessage=PIPageFactory.getFatherName().getText();
				if(expectedMessage.equals(actualMessage))
		            driver.switchTo().alert().accept();
		        else
		            System.out.println("Correct Name...");
		       
		        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		        driver.close();
	    throw new PendingException();
	}

	@When("^user enters invalid Date Format$")
	public void user_enters_invalid_Date_Format() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill the Invalid Date Format'$")
	public void displays_Please_fill_the_Invalid_Date_Format() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid Gender$")
	public void user_enters_invalid_Gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please select the Gender'$")
	public void displays_Please_select_the_Gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid Mobile Number$")
	public void user_enters_invalid_Mobile_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill the Mobile No'$")
	public void displays_Please_fill_the_Mobile_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid (\\d+) digit Mobile No$")
	public void user_enters_invalid_digit_Mobile_No(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please enter (\\d+) digit Mobile No'$")
	public void displays_Please_enter_digit_Mobile_No(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@When("^user enters invalid Mail Id$")
	public void user_enters_invalid_Mail_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@Then("^displays 'Please fill the Mail Id'$")
	public void displays_Please_fill_the_Mail_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@When("^user enters invalid LandLine$")
	public void user_enters_invalid_LandLine() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill the Land Line No'$")
	public void displays_Please_fill_the_Land_Line_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid Communcation$")
	public void user_enters_invalid_Communcation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please select Communcation'$")
	public void displays_Please_select_Communcation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters valid PersonalInformation details$")
	public void user_enters_valid_PersonalInformation_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Personal Details are validated!!!'$")
	public void displays_Personal_Details_are_validated() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
