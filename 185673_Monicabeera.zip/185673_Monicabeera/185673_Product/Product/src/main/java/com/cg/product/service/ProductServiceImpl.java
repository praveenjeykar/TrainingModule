package com.cg.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.Product;
import com.cg.product.dao.IProductRepo;
import com.cg.product.exception.ProductException;

@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductRepo iproductRepo;
	/***
     * Author: Monica Beera
     * Date of Creation: 30/07/2019
     * Method Name: CreateProduct
     * Parameters: Product pro
     * Return Value: Display all the products 
     * Purpose: To Create
     */
	@Override
	public List<Product> CreateProduct(Product pro) throws ProductException {
		try {
			iproductRepo.save(pro);
			return iproductRepo.findAll();
		}
		 catch(Exception e) {
				throw new ProductException(e.getMessage());
	}
	}
	/***
     * Author: Monica Beera
     * Date of Creation: 30/07/2019
     * Method Name:UpdateProduct 
     * Parameters: String id, Product pro  
     * Purpose: To Update
     */
	@Override
	public List<Product> UpdateProduct(String id, Product pro) throws ProductException {
		try {
            Optional<Product> optional = iproductRepo.findById(id);
            if(optional.isPresent()) {
                Product prod = optional.get();
                prod.setName(pro.getName());
                prod.setModel(pro.getModel());
                prod.setPrice(pro.getPrice());
                iproductRepo.save(prod);
                return ViewProducts();
            }
            else {
                throw new ProductException("Customer with ID " + id + " does not exist.");
            }
        } 
		catch (Exception e) {
            throw new ProductException(e.getMessage());
        }
	}
	/***
     * Author: Monica Beera
     * Date of Creation: 30/07/2019
     * Method Name:DeleteProduct 
     * Parameters: String Id
     * Purpose: To delete the products
     */
	@Override
	public void DeleteProduct(String Id) throws ProductException {
		try {
			iproductRepo.deleteById(Id);
		}
		catch(Exception e) {
			throw new ProductException(e.getMessage());
	}
		
	}
	/***
     * Author: Monica Beera
     * Date of Creation: 30/07/2019
     * Method Name:ViewProducts 
     * Return Value: Displays all the Products 
     * Purpose: To View the Products
     */
	@Override
	public List<Product> ViewProducts() throws ProductException {
		try {
	          return iproductRepo.findAll();
		}
			catch(Exception e) {
				throw new ProductException(e.getMessage());
	    }	
	}
	/***
     * Author: Monica Beera
     * Date of Creation: 30/07/2019
     * Method Name: FindProduct
     * Parameters:String Id 
     * Return Value: To find all the products by Id 
     * Purpose: To find Product 
     */
	@Override
	public Product FindProduct(String Id) throws ProductException {
		try{
			return iproductRepo.findById(Id).get();
		}
	  catch(Exception e) {
		throw new ProductException(e.getMessage());
	}
	}

}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
