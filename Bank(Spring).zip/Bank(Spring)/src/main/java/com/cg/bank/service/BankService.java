package com.cg.bank.service;

import java.util.List;

import com.cg.bank.bean.Bank;
import com.cg.bank.exception.BankException;


public interface BankService {
		
	boolean createAccount(Bank bank) throws BankException;
	double  deposit(int account,double amount) throws BankException;
	double  withdraw(int account,double  amount) throws BankException;
	double showBalance(int account) throws BankException;
	Bank loginByUserName(String userName, String password) throws BankException;
	String fundTrnasfer(int sender, int receiver, int amount) throws BankException;
}
