package com.cg.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bank.bean.Bank;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class BankController {
	@Autowired
	BankService bankservice;
	
	@PostMapping("/create")
	public boolean createAccount(@RequestBody Bank bank) throws BankException{
		return bankservice.createAccount(bank);		
	}
	
	@PutMapping("/deposit/{account}/{amount}")
	public double deposit(@PathVariable int account, @PathVariable double amount) throws BankException {
		return bankservice.deposit(account, amount);
		
	}
	
	@PutMapping("/withdraw/{account}/{amount}")
	public double  withdraw(@PathVariable int account,@PathVariable double  amount) throws BankException {
		return bankservice.withdraw(account, amount);
	}
		
	@RequestMapping("/showbalance/{account}")
	public double showbalance(@PathVariable int account) throws BankException {
		return bankservice.showBalance(account);		
	}
	
	@RequestMapping("/login/{userName}/{password}")
	public Bank loginByUserName(@PathVariable String userName,@PathVariable String password) throws BankException {
		return bankservice.loginByUserName(userName, password);		
	}
	
	@RequestMapping("/transfer/{sender}/{receiver}/{amount}")
	public String fundTrnasfer(@PathVariable int sender,@PathVariable int receiver,@PathVariable int amount) throws BankException {
		return bankservice.fundTrnasfer(sender, receiver, amount);		
	}
	
}
