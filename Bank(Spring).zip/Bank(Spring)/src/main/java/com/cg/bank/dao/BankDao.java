package com.cg.bank.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.bank.bean.Bank;


@Repository
public interface BankDao extends JpaRepository<Bank, Integer> {
	@Query("from Bank where account=:accno")
    Bank getByAccountNo(@Param("accno") int account);
	@Query("from Bank where userName=:user")
    Bank getLoginByUsername(@Param("user") String userName);
	@Query("from Bank where password=:pwd")
    Bank getPasswordByUsername(@Param("pwd") String password);

}
