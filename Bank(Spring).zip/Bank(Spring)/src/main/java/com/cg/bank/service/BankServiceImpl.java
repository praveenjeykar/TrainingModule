package com.cg.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Bank;
import com.cg.bank.dao.BankDao;
import com.cg.bank.exception.BankException;

@Service
public class BankServiceImpl implements BankService {
	@Autowired
	BankDao dao;
	

	@Override
	public boolean createAccount(Bank bank) throws BankException {
		try {
		dao.save(bank);
		return true;
		}
		catch(Exception e) {
			throw new BankException("Unable to create account\nEnter valid Details");
		}
	}

	@Override
	public double deposit(int account, double amount) throws BankException{
		try{
		Bank bank=dao.getByAccountNo(account);		
		bank.setBalance(bank.getBalance()+amount);
		dao.save(bank);
		return bank.getBalance();
		}
		catch(Exception e) {
			throw new BankException("Invalid account number");
		}
	}

	@Override
	public double  withdraw(int account, double  amount) throws BankException{
		try {
		Bank bank=dao.getByAccountNo(account);
		bank.setBalance(bank.getBalance()-amount);
		dao.save(bank);
		return bank.getBalance();
		}
		catch(Exception e) {
			throw new BankException("Invalid account number");
		}
		
	}

	@Override
	public double showBalance(int account) throws BankException{
		try {
		Bank bank=dao.getByAccountNo(account);
		return bank.getBalance();
		}
		catch(Exception e) {
			throw new BankException("Invalid account number");
		}
	}

	@Override
	public Bank loginByUserName(String userName, String password) throws BankException{
		try {
		Bank bank = dao.getLoginByUsername(userName);
		dao.getPasswordByUsername(password);
		return bank;
		}
		catch(Exception e) {
			throw new BankException("Invalid UserName and Password");
		}
	}

	@Override
	public String fundTrnasfer(int sender, int receiver, int amount) throws BankException{
		try {
		Bank bank1 =dao.getByAccountNo(sender);
		bank1.setBalance(bank1.getBalance()-amount);
		dao.save(bank1);
		
		Bank bank2 = dao.getByAccountNo(receiver);
		bank2.setBalance(bank2.getBalance()+amount);
		dao.save(bank2);
		return "Transfer Successful";
		}
		catch(Exception e) {
			throw new BankException("Invalid account number. Please verify");
		}
	}

}
