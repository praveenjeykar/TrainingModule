package com.cg.bean;

import java.util.ArrayList;
import java.util.List;

public class Bank {
	private int Id;
	private String Name;
	private String phoneNumber;
	private int accountNumber;
	private int pin;
	private double balance;
	private List<String> trans = new ArrayList<String>();
	public Bank(int Id,String Name, String phoneNumber, int  accountNumber,int pin, double balance) {
		this.Id=Id;
		this.Name=Name;
		this.phoneNumber=phoneNumber;
		this.accountNumber= accountNumber;
		this.pin=pin;
		this.balance=balance;		
	}
	public Bank()
	{
		
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public List<String> gettrans() {
		return trans;
	}
	@Override
	public String toString() {
		return "Bank [Id=" + Id + ", Name=" + Name + ", phoneNumber=" + phoneNumber + ", accountNumber=" + accountNumber
				+ ", pin=" + pin + ", balance=" + balance + ", trans=" + trans + "]";
	}
	public void settrans(List<String> trans) {
		this.trans = trans;
	}
}
	