package com.cg.presentation;

import java.util.Random;
import java.util.Scanner;

import com.cg.bean.Bank;
import com.cg.service.ServiceImpl;

public class BankUI {

	Bank bank= new Bank();
	ServiceImpl service = new ServiceImpl();
	Scanner sc = new Scanner(System.in);
	public void register() {
		
		String Name;
		String phoneNumber;
		double balance;
		int pin;
		
		System.out.println("Enter name:");
		Name=sc.next();
		bank.setName(Name);
		
		System.out.println("Enter Phone Number:");
		phoneNumber=sc.next();
		bank.setPhoneNumber(phoneNumber);
		
		
		System.out.println("Enter amount:");
		balance=sc.nextInt();
		bank.setBalance(balance);		
		
		System.out.println("Enter pin:");
		pin = sc.nextInt();
		bank.setPin(pin);
		
		Random rand = new Random();
		int acc = rand.nextInt(1000);
		bank.setAccountNumber(acc);	
		
		service.createAccount(bank);
		System.out.println("Sucessfully Created" +bank.getAccountNumber());
	}



}
