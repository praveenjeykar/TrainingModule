package com.cg.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.cg.bean.Bank;
import com.cg.dao.DatabaseImpl;

public class ServiceImpl implements Service {
	Scanner sc = new Scanner(System.in);
	DatabaseImpl db = new DatabaseImpl();
	@Override
	public void createAccount(Bank bank) {
		String Name;
		String phoneNumber;
		double balance;
		int pin;
		
		System.out.println("Enter name:");
		Name=sc.next();
		bank.setName(Name);
		
		System.out.println("Enter Phone Number:");
		phoneNumber=sc.next();
		bank.setPhoneNumber(phoneNumber);
		
		
		System.out.println("Enter amount:");
		balance=sc.nextInt();
		bank.setBalance(balance);		
		
		System.out.println("Enter pin:");
		pin = sc.nextInt();
		bank.setPin(pin);
		
		Random rand = new Random();
		int acc = rand.nextInt(200);
		bank.setAccountNumber(acc);	
		
		db.createAcc(bank);
		
	}
	@Override
	public double showBalance() {
		int accNo;
		int pin;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		
		List<Bank> blcList = db.getList();
		for(Bank blclist:blcList) {
			if((blclist.getAccountNumber()==accNo)&&(blclist.getPin()==pin)) {
				System.out.println("Balance = "+blclist.getBalance());
				return blclist.getBalance();
			}
			
		}
		return 0;
		
	}
	@Override
	public double deposit() {
		int accNo;
		int pin;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		
		List<Bank> blcList = db.getList();
		for(Bank blclist:blcList) {
			if((blclist.getAccountNumber()==accNo)&&(blclist.getPin()==pin)) {
				double amount;
				System.out.println("Enter amount to deposit");
				amount = sc.nextInt();
				blclist.gettrans().add("Credited amount: "+amount);
				amount=blclist.getBalance()+amount;
				blclist.setBalance(amount);				
				System.out.println("Balance = "+blclist.getBalance());
				return blclist.getBalance();
			}			
		
	}
		return 0;
	}
	@Override
	public double withdraw() {
		int accNo;
		int pin;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		
		List<Bank> blcList = db.getList();
		for(Bank blclist:blcList) {
			if((blclist.getAccountNumber()==accNo)&&(blclist.getPin()==pin)) {
				double amount;
				System.out.println("Enter amount to withdraw");
				amount = sc.nextInt();
				blclist.gettrans().add("Debited amount: "+amount);
				amount=(blclist.getBalance())-amount;
				
				blclist.setBalance(amount);
				System.out.println("Balance = "+blclist.getBalance());
				return blclist.getBalance();
			}			
		}
		return 0;	
		
	}
	@Override
	public void fundTransfer() {
		int accNo,pin,receiver;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		System.out.println("Enter the account number to credit the money");
		receiver=sc.nextInt();
		
		List<Bank> customerList = db.getList();
		for(Bank A1:customerList) {
			for(Bank A2:customerList) {
				if((accNo==A1.getAccountNumber()) && receiver==A2.getAccountNumber()) {
					if((pin==A1.getPin())) {
					int amt;
					System.out.println("Enter the amount to transfer");
					amt=sc.nextInt();
					A2.setBalance(A2.getBalance()+amt);
					A1.setBalance(A1.getBalance()-amt);
					System.out.println("Successfully transferred");
					}	
				}
				}
				
				}
			}
		
		
	
	@Override
	public List<String> printTranscations() {
		int accNo;
		int pin;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		
		List<Bank> blcList = db.getList();
		for(Bank blclist:blcList) {
			if((blclist.getAccountNumber()==accNo)&&(blclist.getPin()==pin)) {
				System.out.println(blclist.gettrans());
			}			
		}
		
		return null;
	}
	}
	