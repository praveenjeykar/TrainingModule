package com.cg.service;

import java.util.List;

import com.cg.bean.Bank;


public interface Service {
	void createAccount(Bank bank);
	double showBalance();
	double deposit();
	double withdraw();
	void fundTransfer();
	List<String>printTranscations();
}
