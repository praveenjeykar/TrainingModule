package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Bank;

public class DatabaseImpl{
	static ArrayList<Bank> list = new ArrayList<Bank>();
	static {
	Bank details1 = new Bank(1,"Monica","8919237529",1011,1110,200000.0);
	Bank details2 = new Bank(1,"Praveen","9133193881",1007,7080,1000000.0);
	Bank details3 = new Bank(1,"Lalitha","8976543290",1818,8888,50000.0);
	list.add(details1);
	list.add(details2);
	list.add(details3);
	}
	Bank bank = new Bank();
	public void createAcc(Bank bank)
	{
		list.add(bank);
		System.out.println(bank);
	}

	public double showBlc() {
		return bank.getBalance();
	}
	
	public List<Bank> getList() {
		
		return list;
	}
	
	
}
