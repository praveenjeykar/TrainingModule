package com.cg.dao;

import com.cg.bean.Bank;

public interface Database {
}
