package com.cg;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Author {
	@Id
	private int Id;
	private String firstName;
	private String middleName;
	private String lastname;
	private int phoneNo;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Author [Id=" + Id + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastname=" + lastname + ", phoneNo=" + phoneNo + "]";
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
}
