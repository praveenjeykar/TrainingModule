package com.capg.assignment2;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;


@Entity
public class Author2 {
	@Id
	@GeneratedValue()	
	private int id;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(joinColumns=@JoinColumn(name="AuthorId"),inverseJoinColumns=@JoinColumn(name="BookISBN"),name = "BookAuthor")
	private List<Book2> book = new ArrayList<>();	
	@Override
	public String toString() {
		return "Author2 [id=" + id + ", book=" + book + ", name=" + name + "]";
	}
	private String name;
	
	public List<Book2> getBook() {
		return book;
	}
	public void setBook(List<Book2> book) {
		this.book = book;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


}
