package com.cg.empapp.service;

import java.util.List;

import com.cg.empapp.bean.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees();
	Employee getEmployeeById(int id);
	void updateEmployee(Employee emp);
	void addEmployee(Employee emp);
	void deleteEmployee(int id);
	List<Employee> getEmployeeByGender(String gender);
	
}
