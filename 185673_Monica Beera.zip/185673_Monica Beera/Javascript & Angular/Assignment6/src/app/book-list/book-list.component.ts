import { Component, OnInit } from '@angular/core';
import { BooklistService } from '../booklist.service';
import {Ibook} from 'src/app/ibook'
@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
  books;
  BooklistService: any;
  constructor(private booklistService:BooklistService) {}  

  ngOnInit() {
    this.booklistService.getBooks().subscribe(data=>this.books=data);
  }

}
