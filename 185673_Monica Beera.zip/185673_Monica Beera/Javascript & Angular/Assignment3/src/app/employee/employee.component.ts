import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  Employees: any[] = [
    {
      "empId": 1001,
      "empName": "Rahul",
      "empSalary": 9000,
      "empDepartment": "Java"
    },
    {
      "empId": 1002,
      "empName": "Sachin",
      "empSalary": 19000,
      "empDepartment": "OraApps"
    },
    {
      "empId": 1003,
      "empName": "Vikash",
      "empSalary": 29000,
      "empDepartment": "BI"
    }
  ]
  updateId: number;
  updateName: String;
  updateSal: number;
  updateDep: String;
  updateres: any;
  constructor() { }

  ngOnInit() {
  }
  AddEmployee(id:number,name:String,salary:number,department:String){
    let uId = id;
    let uName = name;
    let uSalary = salary;
    let uDepartment = department;
    this.Employees.push({"empId":uId,"empName":uName,"empSalary":uSalary,"empDepartment":uDepartment});
  }
  update(emp){
    this.updateId=emp.empId;
    this.updateName=emp.empName;
    this.updateSal=emp.empSalary;
    this.updateDep=emp.empDepartment;
    this.updateres=emp;
    }
    updateEmployee(updateId:number,updateName:string,updateSal:number,updateDep:string){
    this.updateres.empId=updateId;
    this.updateres.empName=updateName;
    this.updateres.empSalary=updateSal;
    this.updateres.empDepartment=updateDep;
    }
    delete(emp){
    this.Employees.splice(this.Employees.indexOf(emp),1);
    }
    
    
   }

