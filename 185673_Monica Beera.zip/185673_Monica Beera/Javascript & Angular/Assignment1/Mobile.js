"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(name, cost, id) {
        this.mobileCost = cost;
        this.mobileId = id;
        this.mobileName = name;
    }
    Mobile.prototype.printMobile = function () {
        console.log(this.mobileName);
        console.log(this.mobileCost);
        console.log(this.mobileId);
    };
    return Mobile;
}());
exports.Mobile = Mobile;
