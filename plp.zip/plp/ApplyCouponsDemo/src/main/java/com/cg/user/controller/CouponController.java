package com.cg.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.user.bean.Coupon;
import com.cg.user.service.CouponService;


//@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CouponController {
	@Autowired
	CouponService couponService;
	
	@RequestMapping(value = "ApplyCoupon/{ProdId}")
	public double FinalAmount(@PathVariable String ProdId) {
		return couponService.ApplyDiscount(ProdId);	
	}
	
	@RequestMapping(value="DisplayDiscount/{couponCode}")	
		public int displayDiscount(@PathVariable String couponCode){
			return couponService.displayDiscount(couponCode);
	}
	
	@PostMapping(value="/add")
	public List<Coupon> addCoupon(@RequestBody Coupon coupon){		
		return couponService.addCoupon(coupon);		
	}
}


///ecommerce/185673/


	
