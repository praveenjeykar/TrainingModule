package com.cg.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.user.bean.Coupon;
import com.cg.user.dao.CouponDao;
@Service
public class CouponServiceImpl implements CouponService{
	@Autowired
    CouponDao couponDao;

	@Override
	public double ApplyDiscount(String prodId) {
		Coupon coupon = couponDao.getCouponById(prodId);
		double finalPrice=(coupon.getPrice())-((coupon.getPrice())*(coupon.getDiscount())/100);
		return finalPrice;
	}

	@Override
	public int displayDiscount(String couponCode) {
		Coupon coupon = couponDao.findById(couponCode).get();
		return coupon.getDiscount();
	}

	@Override
	public List<Coupon> addCoupon(Coupon coupon) {
		couponDao.save(coupon);
		return couponDao.findAll();
	}
			
}


