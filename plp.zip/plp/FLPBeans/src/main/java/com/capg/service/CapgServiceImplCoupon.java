package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capg.dao.CapgCouponRepo;


@Service
public class CapgServiceImplCoupon implements CapgServiceCoupon {
	@Autowired
	CapgCouponRepo capgCouponRepo;
   
	@Override
	public String ApplyDiscount(String coupCode, int discount) {
		Coupon cu=
		return null;
	   
	}


	
	
}

	
	

