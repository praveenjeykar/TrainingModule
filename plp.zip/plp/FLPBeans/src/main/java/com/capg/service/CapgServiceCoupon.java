package com.capg.service;

public interface CapgServiceCoupon {
  public String ApplyDiscount(String coupCode,int discount);
}
