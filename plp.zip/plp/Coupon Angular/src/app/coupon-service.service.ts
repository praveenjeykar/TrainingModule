import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ICoupon } from './icoupon';

@Injectable({
  providedIn: 'root'
})
export class CouponServiceService {

  icoupon:ICoupon[];
  id: string;
  constructor(private http: HttpClient) { }

  public applyCoupon(): Observable<number> {
    
    return this.http.get<number>("http://localhost:8088/ApplyCoupon/"+this.id);
  }

  public displayDiscount(couponCode): Observable<ICoupon>{
    return this.http.get<ICoupon>("http://localhost:8088/DisplayDiscount/"+couponCode);
  }
  Icoupon = new ICoupon();
  Id: String;
  public setId(id1:string) {
    this.id=id1;
  }

  public  getId(){
    return this.Icoupon.prodId;
  }

}
