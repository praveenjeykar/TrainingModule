export class ICoupon {
    couponCode:string;
    prodId:string;
    price:number;
    discount:number;
}