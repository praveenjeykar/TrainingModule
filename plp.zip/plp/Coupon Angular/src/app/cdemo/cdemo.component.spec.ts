import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CDemoComponent } from './cdemo.component';

describe('CDemoComponent', () => {
  let component: CDemoComponent;
  let fixture: ComponentFixture<CDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
