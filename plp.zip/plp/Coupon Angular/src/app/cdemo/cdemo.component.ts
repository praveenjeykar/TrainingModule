import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CouponServiceService } from '../coupon-service.service';
import { ICoupon } from '../icoupon';

@Component({
  selector: 'app-cdemo',
  templateUrl: './cdemo.component.html',
  styleUrls: ['./cdemo.component.css']
})
export class CDemoComponent implements OnInit {
 
  
  discountP : number;
  price : number;
  temp = new ICoupon();
  constructor(private router:Router, private couponService:CouponServiceService) { }

  ngOnInit() {
  }
  displayDiscount(coupon){
    this.couponService.displayDiscount(coupon).subscribe(data=>{
      this.discountP=data.discount;
      this.couponService.setId(data.prodId);
      
    
    },error=>{alert("Incorrect CouponCode")});
    };
    applyCoupon(){
      this.couponService.applyCoupon().subscribe(data=>{
        this.price=data;
        
      
      },error=>{alert("Incorrect CouponCode")});
      };
  }

