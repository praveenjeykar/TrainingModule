import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CDemoComponent } from './cdemo/cdemo.component';


const routes: Routes = [
  {path :'CDemo',component : CDemoComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingcomponents=[CDemoComponent]