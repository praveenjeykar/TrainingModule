package com.cg.product.service;

import com.cg.product.bean.Product;


public interface IProductService {
	public double CalDiscount(String prodId);


}
