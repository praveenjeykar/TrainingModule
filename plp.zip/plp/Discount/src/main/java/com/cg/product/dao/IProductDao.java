package com.cg.product.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.product.bean.Product;



public interface IProductDao extends JpaRepository<Product, String> {


@Query("from Product where prodId=:proid")
	Product getProductById(@Param("proid") String prodId);

}
