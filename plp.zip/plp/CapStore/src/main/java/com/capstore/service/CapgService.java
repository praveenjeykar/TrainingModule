package com.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.Customer;
import com.capstore.bean.WishItem;
import com.capstore.dao.CustomerDao;
import com.capstore.dao.WishItemDao;

@Service
public class CapgService {

	@Autowired CustomerDao customerRepo;
	@Autowired WishItemDao customerWishRepo;
	public void registerCustomer(Customer customer) {
		customerRepo.save(customer);
	}
	
	public Customer findCustomerById(String custId) {  
		return customerRepo.findById(custId).get();
	}
	public void addCustomerWish(String custId,WishItem wish) {
		Customer customer = findCustomerById(custId);
		List<WishItem> wishList = customer.getWishItems();
		wishList.add(wish);
		customer.setWishItems(wishList);
		customerWishRepo.save(wish);
		customerRepo.save(customer);
	}
}
