package com.cg.bank.service;

import java.util.List;

import com.cg.bank.bean.Bank;


public interface BankService {
		
	List<Bank> createAccount(Bank bank);
	Double showBlc(Bank bank);
	double  deposit(int account,Bank bank,double amount);
	double  withdraw(int account,Bank bank,double  amount);
}
