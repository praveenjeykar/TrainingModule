package com.cg.bank.bean;

	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.SequenceGenerator;
	import javax.validation.constraints.Pattern;

	@Entity 
	public class Bank {
		@SequenceGenerator(name="accNmbr", sequenceName="acc_seq",allocationSize = 1 )
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="accNmbr")
		@Id
		private int account;
		private String Name;		
		@Pattern(regexp="(\\+91(-)?|91(-)?|0(-)?)?((9)|(8)|(7))[0-9]{9}")
		private String phoneNo;
		private String email;
		private String gender;
		private String userName;
		private String password;
		private double balance;
		
		
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public int getAccount() {
			return account;
		}
		public void setAccount(int account) {
			this.account = account;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getPhoneNo() {
			return phoneNo;
		}
		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		@Override
		public String toString() {
			return "Bank [account=" + account + ", Name=" + Name + ", phoneNo=" + phoneNo + ", email=" + email
					+ ", gender=" + gender + ", userName=" + userName + ", password=" + password + ", balance="
					+ balance + "]";
		}


	}
	