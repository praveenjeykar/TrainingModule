package com.cg.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bank.bean.Bank;
import com.cg.bank.service.BankService;

@RestController
public class BankController {
	@Autowired
	BankService bankservice;
	
	@PostMapping("/create")
	public List<Bank> createAccount(@RequestBody Bank bank){
		return bankservice.createAccount(bank);		
	}
	
	@PutMapping("/deposit/{account}/{amount}")
	public double deposit(int account, Bank bank, double amount) {
		return bankservice.deposit(account, bank, amount);
		
	}
	
	@PutMapping("/withdraw/{account}/{amount}")
	public double  withdraw(int account, Bank bank, double  amount) {
		return bankservice.withdraw(account, bank, amount);
	}
		
}
