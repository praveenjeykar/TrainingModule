package com.cg.bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Bank;
import com.cg.bank.dao.BankDao;

@Service
public class BankServiceImpl implements BankService {
	@Autowired
	BankDao dao;
	Optional<Bank> temp;
	

	@Override
	public List<Bank> createAccount(Bank bank) {
		dao.save(bank);
		return dao.findAll();
	}

	@Override
	public Double showBlc(Bank bank) {		
		return bank.getBalance();
	}

	@Override
	public double deposit(int account, Bank bank, double amount) {
		temp = dao.findById(account);
		bank.setBalance(bank.getBalance()+amount);
		return amount;
	}

	@Override
	public double  withdraw(int account, Bank bank, double  amount) {
		temp = dao.findById(account);
		bank.setBalance(bank.getBalance()-amount);
		return amount;
		
	}

}
