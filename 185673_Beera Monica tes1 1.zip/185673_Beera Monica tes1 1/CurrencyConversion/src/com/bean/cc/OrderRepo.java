package com.bean.cc;

public interface OrderRepo {

}
