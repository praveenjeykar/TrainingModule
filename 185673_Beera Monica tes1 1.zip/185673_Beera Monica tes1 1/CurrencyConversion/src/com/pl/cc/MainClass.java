package com.pl.cc;

import java.util.ArrayList;
import java.util.Scanner;

public class MainClass {
  public static void main(String args[]) {
	  while(true) {
	//Menu Driven Window to Deal with user inputs
	  System.out.println("CURRENCY CONVERSION");
	  System.out.println();
	  System.out.println("1. Caluculate the price in local currency");
	  System.out.println("2. Display the Details");
	  System.out.println("3. exit");
	  System.out.println("Please enter your choice: ");
	  int n;
      Scanner sc = new Scanner(System.in);
      n=sc.nextInt();
      ArrayList<String> a = new ArrayList<String>();
      a=null;
      switch(n)
      {
      case 1: UserInputcc ui = new UserInputcc();
              ui.readInput(); //call readInput() for read the data from the user
              break;
      case 2: DisplayOutputcc op = new DisplayOutputcc();
              op.showOutputcc(null); //call showOutput() for Display all the details
              break;        
  
      case 3: System.exit(0);     //to terminate the program        

      default:System.out.println("Enter the correct input...");
              break;
       //sc.close();        
      }
  }
  }
}

