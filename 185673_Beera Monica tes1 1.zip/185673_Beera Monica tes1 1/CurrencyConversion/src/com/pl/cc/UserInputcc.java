package com.pl.cc;

import com.bean.cc.Order;
import com.sr.cc.Servicecc;


import java.util.*;

public class UserInputcc {
	 public void readInput() {		 

	  Servicecc sr= new Servicecc();
	  int id;
	  double price;
	  int quantity;
	  double amount;
	  double charges;
	  Scanner sc= new Scanner(System.in);
	 
	  Order obj = new Order();  //created object of bean class
	 
	  System.out.print("Enter the ID");
	  id=sc.nextInt();
	  obj.setId(id);
	  
	  System.out.print("Enter the Price");
	  price=sc.nextInt();
	  obj.setPrice(price);
	  
	  System.out.print("Enter the Quantity");
	  quantity=sc.nextInt();
	  obj.setQuantity(quantity);
	  
	  System.out.println("Enter the Amount");
	  amount=sc.nextInt();
	  obj.setAmount(amount);
	  
	  System.out.print("Enter the Charges");
	  charges=sc.nextInt();
	  obj.setCharges(charges);
	  
	  sc.close();
	  sr.calculate(obj);
  }
}
