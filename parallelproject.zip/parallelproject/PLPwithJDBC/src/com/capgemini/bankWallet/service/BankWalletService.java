package com.capgemini.bankWallet.service;


import com.capgemini.bankWallet.exception.InsufficientBalanceException;

public interface BankWalletService 
{
  boolean createAccount( String name, String mobileNo, String aadharNo,String pin);
  long showBalance(int accountNo,String pin);
  long deposit(int accountNo,long amount);
  long withdraw(int accountNo,String pin,long amount) throws InsufficientBalanceException;
  boolean fundTransfer(int sourceAcNo,int destAcNo,long amount,String pin) throws InsufficientBalanceException;
  boolean validateAccountNumber(int accNo);
  boolean validateName(String name);
  boolean validateMobileNumber(String mobileNo);
  boolean validateAadharNumber(String aadharNo);
  boolean validatePin(String pin);
  void ptr(int accountNo);
}
