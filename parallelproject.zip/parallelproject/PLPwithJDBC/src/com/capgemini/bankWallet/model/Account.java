package com.capgemini.bankWallet.model;

import java.util.ArrayList;
import java.util.List;

public class Account 
{
  static int accountNo=1000;
  String name;
  String mobileNo;
  String aadharNo;
  long accountBalance;
  int accno;
  public List<String> tl = new ArrayList<>();
  public List<String> getTl() {
	  
	return tl;
}
public void setTl(String s) {
	tl.add(s);
}
String pin;
  public Account() {
	super();
  }
  public Account(String name, String mobileNo, String aadharNo, long accountBalance, String pin) {
	super();
	this.name = name;
	this.mobileNo = mobileNo;
	this.aadharNo = aadharNo;
	this.accountBalance = accountBalance;
	this.pin = pin;
  }
  public int getAccountNo() {
	return accno;
  }
  public void setAccountNo() {
	accno=accountNo++;
  }
  public String getName() {
	return name;
  }
  public void setName(String name) {
	this.name = name;
  }
  public String getMobileNo() {
	return mobileNo;
  }
  public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
 }
 public String getAadharNo() {
	return aadharNo;
 }
 public void setAadharNo(String aadharNo) {
	this.aadharNo = aadharNo;
 }
 public long getAccountBalance() {
	return this.accountBalance;
 }
 public void setAccountBalance(long accountBalance) {
	this.accountBalance = accountBalance;
 }
 public String getPin() {
	return pin;
  }
 public void setPin(String pin) {
	this.pin = pin;
 }
 @Override
 public String toString() {
	return "BankAccount [accountNo=" + accountNo + ", name=" + name + ", mobileNo=" + mobileNo + ", aadharNo="
			+ aadharNo + ", accountBalance=" + accountBalance + ", pin=" + pin + "]";
 } 
}
