package com.capg.assignment1;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class BookDetails {
	@Id
	private int ISBN;
	private int price;
	private String title;
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "BookDetails [ISBN=" + ISBN + ", price=" + price + ", title=" + title + "]";
	}
}
