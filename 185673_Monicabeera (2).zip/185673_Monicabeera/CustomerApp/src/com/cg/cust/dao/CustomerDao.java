package com.cg.cust.dao;

import org.springframework.data.jpa.repository.JpaRepository; //generic interface
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.cust.bean.Customer;


@Repository
public interface CustomerDao extends JpaRepository<Customer, Integer>{
	
	@Query("from Customer where custId=:customerId")
	Customer getCustomreById(@Param("customerId")int id);
}
