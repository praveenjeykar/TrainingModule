package execrise4;

import java.util.Scanner;

public class CubeofNumbers {
	public static void main(String args[]) {
		CubeofNumbers();
	}
	public static void CubeofNumbers() {
		int n,t,sum=0;
		Scanner sc = new Scanner(System.in);
		n=sc.nextInt();
		
		while(n>0) {
			t=n%10;
			sum=sum+(t*t*t);
			n=n/10;
		}
		sc.close();
   System.out.println(sum);
}
}
