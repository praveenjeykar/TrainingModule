package com.mo;

import java.util.Arrays;
import java.util.Scanner;

public class getSecondSmallest {  
		public static void main(String args[])
		{  
		  SecondSmallest();
		}
		
public static void SecondSmallest() {
	Scanner sc=new Scanner(System.in);
	int[] a =new int[5];
	for(int i=0;i<5;i++) {
		a[i]=sc.nextInt();
	}
	sc.close();
	Arrays.sort(a);
	System.out.println("Second smallest number is: " +a[1]);
}		  
	 } 
