import java.io.*;
public class Ecercise3 {
public static void main(String args[]) throws IOException {
	File file = new File("C:\\Users\\mbeera\\Desktop\\MoniMonica.txt");
	BufferedReader b= new BufferedReader(new FileReader(file));
	String str;
	int linecount=0,charcount=0;
	String[]word=null;
	int wordcount=0;
	while((str=b.readLine())!=null) {
		linecount++;
		if(!(str.equals(""))) {
			charcount =charcount +str.length();
			word =str.split(" ");
			wordcount =wordcount +word.length;
		}
		
		b.close();
}             
	System.out.println(charcount +" "+linecount +" "+ wordcount);
}
}
