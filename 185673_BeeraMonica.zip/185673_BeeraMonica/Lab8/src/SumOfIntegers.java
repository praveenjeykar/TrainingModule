import java.util.*;
import java.util.StringTokenizer;

public class SumOfIntegers {
	public static void main(String args[]) { 
       int n,sum=0;
       StringTokenizer stn= new StringTokenizer("1 2 3 4 5 6 7 8 9 10 "," ");
       while(stn.hasMoreTokens()) {
    	   n=Integer.parseInt(stn.nextToken());
    	   System.out.println("each integers in the line is");
    	   sum=sum+n;
    	   System.out.println("Sum of integers is" +sum);
       }
}
}
