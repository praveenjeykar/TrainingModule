package exercise5;
import java.util.*;
public class Ex6 {
class ThrowException extends RuntimeException{
		
		public String toString() {
			return "Exception found";
		} 
public void main(String args[]) {
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter salary");
	int sal = sc.nextInt();
	sc.close();
	try {
		if(sal<3000)
			throw new ThrowException();
	}
	catch(Exception e) {
		System.out.println(e);	
	}
}
}
}
