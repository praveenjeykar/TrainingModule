package exercise5;
import java.util.*;

public class AgeValidation extends RuntimeException{
	public String toString() {
		return "Exception found bcoz of invalidAge";
	} 
	public static void main(String args[]) {
		int age;
		System.out.println("enter the age");
		Scanner sc= new Scanner(System.in);
		age= sc.nextInt();
		sc.close();
		try {
			if(age<=15)
				throw new AgeValidation();
			else
				System.out.println("valid age");
		}
		catch (Exception e) {
			System.out.println("age of the person should above 15");
		}
		
		
	}		
	}
