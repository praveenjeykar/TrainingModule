package exercise5;
import java.util.*;
public class NameValidation {
	public static void main(String args[]) {
		String str;
		System.out.println("enter the string");
		Scanner sc=new Scanner(System.in);
		str=sc.nextLine();
		if(str.matches("[A-Z]+([ ]|[a-zA-Z]+)*"))
		System.out.println("valid name");
		else
			System.out.println("invalid name");
	}

}
