package exercise5;
import java.util.Scanner;
public class Exercise2 {
	
		public static void nonrecursion(int n) {
			int a=1,b=1,c,i = 0;
			if(n<=2)
				System.out.println(1);
			while(i<n-2) {
				//System.out.println("Entire fib series " + b);
				c = a+b;
				a = b;
				b = c;
				i++;			
			}
			System.out.println("nth fib using non recursion " + b);
		}
		static int recursion(int n2) {
			if(n2<=2)
				return 1;
			else
				return recursion(n2-1) + recursion(n2-2);
		}
		public static void main(String args[]) {
			int n,n2;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the number ");
			n = sc.nextInt();
			n2=n;
			nonrecursion(n);
			recursion(n2);
			sc.close();
			System.out.println("nth fib using recursion "+ recursion(n2));
		}
	}

