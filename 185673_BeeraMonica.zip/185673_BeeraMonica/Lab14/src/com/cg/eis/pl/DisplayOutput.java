package com.cg.eis.pl;
import java.util.ArrayList;

	 

	public class DisplayOutput {

	 

	    public void showOutput(ArrayList<String> al) {
	        for(String str : al) {
	            System.out.println(str);
	        }
	    }
	}
	 

	
