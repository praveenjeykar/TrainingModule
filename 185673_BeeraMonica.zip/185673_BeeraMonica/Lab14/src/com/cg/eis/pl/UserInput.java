package com.cg.eis.pl;
import java.io.IOException;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.Services;

	 
public class UserInput {

	 

	    public void readInput() throws IOException {
	        int empId;
	        String empName;
	        int salary;
	        String empDesignation;
	        
	        
	        Employee employee = new Employee();
	        
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the Employee ID: ");
	        empId = sc.nextInt();
	        employee.setEmpId(empId);
	        
	        System.out.println("Emter the Employee Name: ");
	        empName = sc.next();
	        employee.setName(empName);
	        
	        System.out.println("Enter the Employee Salary: ");
	        salary = sc.nextInt();
	        employee.setSalary(salary);
	        
	        System.out.println("Enter the Employee Designation: ");
	        empDesignation = sc.next().toLowerCase();
	        employee.setDesignation(empDesignation);
	        
	        sc.close();
	        
	        if((salary > 5000) && (salary < 20000) && empDesignation.equals("system associate")) {
	            employee.setInsuranceScheme("Scheme C");
	        }
	        else if((salary >= 20000) && (salary < 40000) && empDesignation.equals("programmer")) {
	            employee.setInsuranceScheme("Scheme B");
	        }
	        else if((salary >= 40000) && empDesignation.equals("manager")) {
	            employee.setInsuranceScheme("Scheme A");
	        }
	        else if((salary < 5000) && empDesignation.equals("clerk")) {
	            employee.setInsuranceScheme("No Scheme");
	        }
	        else
	            employee.setInsuranceScheme("Sorry!! No Scheme");
	        
	        EmployeeService empService = new Services();
	        empService.serviceProvide(employee);
	    }
	}

