package com.cg.eis.service;
	
import java.io.IOException;

import com.cg.eis.bean.Employee;

import com.cg.eis.dao.DataStorage;

	 

	public class Services implements EmployeeService{

	 

	    private String service;
	    
	    public String getService() {
	        return service;
	    }

	 

	    public void setService(String service) {
	        this.service = service;
	    }

	 

	 

	    @Override
	    public void serviceProvide(Employee emp) {
	        
	        Services s = new Services();
	        //System.out.println(emp.getInsuranceScheme());
	        if(emp.getInsuranceScheme().equals("Scheme A")) {
	            s.setService("Free Shopping and other perks");
	        }
	        else if(emp.getInsuranceScheme().equals("Scheme B")) {
	            s.setService("Free Movie Tickets and other perks");
	        }
	        else if(emp.getInsuranceScheme().equals("Scheme C")) {
	            s.setService("Only company perks");
	        }
	        else if(emp.getInsuranceScheme().equals("No Scheme")) {
	            s.setService("Sorry!! You are not Eligible for any Schemes");
	        }
	        else
	            s.setService("Sorry!! You are not Eligible for any Schemes");
	        
	        DataStorage ds = new DataStorage();
	        try {
	            ds.storeData(emp, s);
	        } catch (IOException e) {
	            
	            e.printStackTrace();
	        }
	        
	    }

	 

	}
