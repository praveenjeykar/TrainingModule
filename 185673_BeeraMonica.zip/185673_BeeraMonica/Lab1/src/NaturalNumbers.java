import java.util.Scanner;

public class NaturalNumbers {
	public static void main(String args[]) { 
		  Natnum();
}
	public static void Natnum() {
		   int n,i,sum=0;
		   System.out.println("enter the number");
		   Scanner sc= new Scanner(System.in);
		   n=sc.nextInt();
		   sc.close();
		   for(i=1;i<=n;i++)
		   {
			   if((i%3==0)||(i%5==0)) {
				   sum=sum+i;
			   }
				   
		   }
		   System.out.println("sum " +sum);
}
}