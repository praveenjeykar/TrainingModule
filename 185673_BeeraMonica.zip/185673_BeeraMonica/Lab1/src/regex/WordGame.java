package regex;
import java.util.Scanner;

public class WordGame {
	public static void main(String args[]){
		int n;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Menu\n1. Start\n2. Game Description\n3. Exit\nEnter an option");
		n=sc.nextInt();
		switch(n)
		{
		case 1 :System.out.println("Enter the name:");
		 		String str= sc.next();
			    System.out.println("Welcome "+str);
			    StartGame obj= new StartGame();
			    obj.startGame();
			    break;
		case 2: System.out.println("Game Description");
		        break;
		case 3: System.exit(0);        
		case 4: System.out.println("Invalid option");        
		}
		sc.close();		
	}
}
    
