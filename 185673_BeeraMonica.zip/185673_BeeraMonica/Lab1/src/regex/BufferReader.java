package regex;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class BufferReader {
	public static void main(String args[])throws Exception {
		String s="d:\\fileread.txt";
		String s1="d:\\buffer.java";
		int i;
		String sr;
		FileReader fr=new FileReader(s);
		BufferedWriter bw=new BufferedWriter(new FileWriter(s1,true));
		
		while((i=fr.read())!=-1){
			bw.flush();
			bw.write(i);
		}
	}

}
