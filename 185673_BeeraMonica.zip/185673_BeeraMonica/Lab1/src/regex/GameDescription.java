package regex;

public class GameDescription {
	void gamedescription() {
		
	}

}
