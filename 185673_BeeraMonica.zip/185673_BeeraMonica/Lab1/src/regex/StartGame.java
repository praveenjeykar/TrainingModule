package regex;

import java.util.Scanner;

public class StartGame {
   void startGame() {
	   int m;
	   Scanner sc= new Scanner(System.in);
	   
	   System.out.println("select an option \n1. City Name\n2. Country Name");
	   m=sc.nextInt();
	   switch(m) {
	   case 1: System.out.println("Guess the City name");
	           CityName cin= new CityName();
	           cin.cityName();
	           break;
	   case 2: System.out.println("Guess the Country name");
               CountryName con= new CountryName();
               con.countryName();  
               break;
       default :System.out.println("Invalid Option"); 
	   }
	   sc.close();
   }
}
