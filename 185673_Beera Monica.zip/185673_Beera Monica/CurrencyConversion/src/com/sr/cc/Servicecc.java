package com.sr.cc;

	import java.util.ArrayList;

	import com.bean.cc.Order;
import com.dao.cc.*;
import com.pl.cc.DisplayOutputcc;



	public class Servicecc implements OrderService {
		 public void calculate(Order obj) {
		         int CalculateOrder(Order obj);
		        {
		        	int OrderAmount=0;
		        	OrderAmount=(int)(obj.getPrice()*75);
		        	return OrderAmount;
		        }
		        public void Calculate void TotalAmount(Order Order)
		        {
		        	double total=0;
		        	double conversion=(1.25/100)*Order.getCharges();
		        	total=Order.getQuantity()*Conversion;
		        	double toatl;
					Order.setAmount(toatl);
		        	
		        }
		       
		       
		        DataBaselayer dbl = new DataBaselayer();
		        int id=dbl.nextInt(100);
		        Order.setId(id);
		        
		 
		        
					
				}
	}


